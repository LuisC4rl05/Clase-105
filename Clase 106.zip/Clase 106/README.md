# PROC106-V1-actividad-alumno1
Python. OpenCV. Plantilla del código.  
  
Lesson plan.  
  
### Texto en inglés: PRO-C106-Student-Boilerplate
PRO-C106-Student-Boilerplate